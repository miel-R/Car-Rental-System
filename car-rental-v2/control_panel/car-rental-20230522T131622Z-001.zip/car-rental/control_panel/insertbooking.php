<!DOCTYPE html>
<html>
<head>
  <title>Loading...</title>
  <style>
    /* CSS for the loading box */
    .loading-box {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      font-size: 24px;
      font-weight: bold;
    }
  </style>
  <script>
    setTimeout(function() {
      window.location.href = "../index.html";
    }, 3000); // Delay in milliseconds before redirecting
  </script>
</head>
<body>
  <div class="loading-box">
    Loading...
  </div>

  <?php
  require_once('dbconn.php');

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $car = $_POST['cars'];
    $startdate = $_POST['startdate'];
    $enddate = $_POST['enddate'];

    // Perform input validation if needed

    // Create a new database connection
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare the SQL statement
    $sql = "INSERT INTO booking_data (firstname, lastname, car, start_date, end_date) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssss", $firstname, $lastname, $car, $startdate, $enddate);

    // Execute the SQL statement
    if (mysqli_stmt_execute($stmt)) {
      mysqli_stmt_close($stmt);
      mysqli_close($conn);
      exit();
    } else {
      echo "Error submitting booking: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
  } else {
    echo "Invalid request.";
  }
  ?>
</body>
</html>