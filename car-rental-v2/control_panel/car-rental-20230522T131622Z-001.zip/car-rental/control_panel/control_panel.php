<?php
// Assuming you have established a database connection
require_once('dbconn.php');
$conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve data from the database
$query = "SELECT id, car, firstname, lastname, number, start_date, end_date, note
          FROM booking_data
          ORDER BY id ASC"; // Fetch data in ascending order
$result = mysqli_query($conn, $query);

// Fetch the data into an array
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Display the data in reverse order
echo "<table>";
echo "<tr>
        <th>ID</th>
        <th>CAR</th>
        <th>FIRST_NAME</th>
        <th>LAST_NAME</th>
        <th>NUMBER</th>
        <th>START_DATE</th>
        <th>END_DATE/th>
        <th>NOTE</th>
      </tr>";

for ($i = count($data) - 1; $i >= 0; $i--) {
    echo "<tr>";
    echo "<td>" . $data[$i]['id'] . "</td>";
    echo "<td>" . $data[$i]['car'] . "</td>";
    echo "<td>" . $data[$i]['firstname'] . "</td>";
    echo "<td>" . $data[$i]['lastname'] . "</td>";
    echo "<td>" . $data[$i]['number'] . "</td>";
    echo "<td>" . $data[$i]['start_date'] . "</td>";
    echo "<td>" . $data[$i]['end_date'] . "</td>";
    echo "<td>" . $data[$i]['note'] . "</td>";
    echo "</tr>";
}

echo "</table>";

// Close the database connection
mysqli_close($conn);
?>